document.addEventListener('DOMContentLoaded', () => {
    const hamburgerBtn = document.getElementById('hamburger-btn');
    const dropdownMenu = document.getElementById('dropdown-menu');
    const programBtn = document.getElementById('program-dropdown-btn');
    const programMenu = document.getElementById('program-nested-menu');

    hamburgerBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        dropdownMenu.classList.toggle('show');
    });

    programBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        programMenu.classList.toggle('show');
    });

    document.addEventListener('click', (e) => {
        if (!dropdownMenu.contains(e.target) && !hamburgerBtn.contains(e.target)) {
            dropdownMenu.classList.remove('show');
            programMenu.classList.remove('show');
        }
    });

    const navLinks = document.querySelectorAll('.nav-link');
    const pages = document.querySelectorAll('.page');

    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            const pageId = link.getAttribute('data-page');
            if (pageId) {
                e.preventDefault();
                
                pages.forEach(page => page.classList.remove('active'));
                
                const targetPage = document.getElementById(pageId);
                if (targetPage) {
                    targetPage.classList.add('active');
                }

                navLinks.forEach(l => l.classList.remove('active'));
                link.classList.add('active');

                dropdownMenu.classList.remove('show');
                programMenu.classList.remove('show');

                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        });
    });

    const sliderTrack = document.getElementById('slider-track');
    const slides = document.querySelectorAll('.slide');
    let currentSlide = 0;

    if (slides.length > 0) {
        setInterval(() => {
            currentSlide = (currentSlide + 1) % slides.length;
            sliderTrack.style.transform = `translateX(-${currentSlide * 100}%)`;
        }, 4000);
    }

    const faqItems = document.querySelectorAll('.faq-item');
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        question.addEventListener('click', () => {
            faqItems.forEach(i => {
                if (i !== item) i.classList.remove('active');
            });
            item.classList.toggle('active');
        });
    });

    const modal = document.getElementById('modal-pendaftaran');
    const closeBtn = document.getElementById('modal-close-btn');
    const openTriggers = document.querySelectorAll('.open-modal-trigger, #hero-daftar-btn');

    openTriggers.forEach(trigger => {
        trigger.addEventListener('click', (e) => {
            e.preventDefault();
            modal.classList.add('show');
        });
    });

    closeBtn.addEventListener('click', () => {
        modal.classList.remove('show');
    });

    window.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.classList.remove('show');
        }
    });

    const regionData = {
        "Jawa Barat": ["Bandung", "Kab. Bandung", "Bandung Barat", "Bekasi", "Bogor", "Ciamis", "Cianjur", "Cirebon", "Garut", "Indramayu", "Karawang", "Kuningan", "Majalengka", "Pangandaran", "Purwakarta", "Subang", "Sukabumi", "Sumedang", "Tasikmalaya", "Depok", "Cimahi"],
        "Jawa Tengah": ["Semarang", "Surakarta", "Magelang", "Banyumas", "Brebes", "Cilacap", "Demak", "Kudus", "Pati", "Pekalongan", "Tegal"],
        "Jawa Timur": ["Surabaya", "Malang", "Kediri", "Madiun", "Sidoarjo", "Gresik", "Banyuwangi", "Jember", "Pasuruan"],
        "DKI Jakarta": ["Jakarta Pusat", "Jakarta Utara", "Jakarta Barat", "Jakarta Selatan", "Jakarta Timur"],
        "Banten": ["Serang", "Tangerang", "Tangerang Selatan", "Cilegon", "Lebak", "Pandeglang"]
    };

    const provSelect = document.getElementById('provinsi');
    const kabSelect = document.getElementById('kabupaten');

    for (let prov in regionData) {
        let opt = document.createElement('option');
        opt.value = prov;
        opt.textContent = prov;
        provSelect.appendChild(opt);
    }

    provSelect.addEventListener('change', () => {
        kabSelect.innerHTML = '<option value="" disabled selected>Pilih Kabupaten/Kota</option>';
        const selectedProv = provSelect.value;
        if (regionData[selectedProv]) {
            regionData[selectedProv].forEach(kab => {
                let opt = document.createElement('option');
                opt.value = kab;
                opt.textContent = kab;
                kabSelect.appendChild(opt);
            });
            kabSelect.disabled = false;
        } else {
            kabSelect.disabled = true;
        }
    });

    const formWA = document.getElementById('form-pendaftaran-wa');
    formWA.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const nama = document.getElementById('nama').value;
        const telepon = document.getElementById('telepon').value;
        const provinsi = document.getElementById('provinsi').value;
        const kabupaten = document.getElementById('kabupaten').value;
        const program = document.getElementById('program').value;

        const pesanWA = `Halo Admin LPK IMM, saya ingin mendaftar pelatihan.%0A%0A*Data Pendaftaran:*%0A- *Nama:* ${nama}%0A- *No WA:* ${telepon}%0A- *Provinsi:* ${provinsi}%0A- *Kabupaten/Kota:* ${kabupaten}%0A- *Program:* ${program}%0A%0AMohon informasi langkah selanjutnya. Terima kasih.`;
        
        const targetNumber = '6285312000653';
        window.open(`https://wa.me/${targetNumber}?text=${pesanWA}`, '_blank');
        
        modal.classList.remove('show');
        formWA.reset();
        kabSelect.disabled = true;
    });
});